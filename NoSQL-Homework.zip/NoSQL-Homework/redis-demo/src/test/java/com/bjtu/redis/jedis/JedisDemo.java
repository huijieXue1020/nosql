package com.bjtu.redis.jedis;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.monitor.FileAlterationMonitor;
import org.apache.commons.io.monitor.FileAlterationObserver;
import org.junit.Test;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import java.io.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class JedisDemo {

    private Long Period;    //读取json得到的周期时长
    private Long start_time;    //开始计时时的时间
    public int max_freq = 0;    //目前最大的周期个数
    private int read_freq = 0;  //json文件已经储存的周期个数

    /**
     * 基本使用
     */
    @Test
    public void basicUse() {
        Jedis jedis = new Jedis("127.0.0.1", 6379);
        System.out.println("服务正在运行: " + jedis.ping());
        //jedis.set("name", "lizai");
        //jedis.setex("namewithttl", 20,"lizai");
        String val = jedis.get("namewithttl");
        System.out.println(val);
        jedis.close();
    }


    /**
     * 封装的set函数
     */
    @Test
    public void RedisSet() {
        Jedis jedis = new Jedis("127.0.0.1", 6379);
        System.out.println("请输入选项（1：添加String 2：添加list 3：添加set 4：添加sortedset 5：添加Hash）");
        Scanner scanner = new Scanner(System.in);
        String option = scanner.nextLine();
        switch (option)
        {
            case "1":
            {
                RedisAddStringKey();
                break;
            }
            case "2":
            {
                RedisAddList();
                break;
            }
            case "3":
            {
                RedisAddSet();
                break;
            }
            case "4":
            {
                RedisAddSortedSet();
                break;
            }
            case "5":
            {
                RedisAddHash();
                break;
            }
            default:
            {
                System.out.println("input error");
            }
        }
        jedis.close();
    }

    //读json文件
    public String readJsonFile(String fileName) {
        String jsonStr = "";
        try {
            File jsonFile = new File(fileName);
            FileReader fileReader = new FileReader(jsonFile);
            Reader reader = new InputStreamReader(new FileInputStream(jsonFile),"utf-8");
            int ch = 0;
            StringBuffer sb = new StringBuffer();
            while ((ch = reader.read()) != -1) {
                sb.append((char) ch);
            }
            fileReader.close();
            reader.close();
            jsonStr = sb.toString();
            return jsonStr;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
    //写json文件
    public static void writeFile(String filePath, String sets)
            throws IOException {
        FileWriter fw = new FileWriter(filePath);
        PrintWriter out = new PrintWriter(fw);
        out.write(sets);
        out.println();
        fw.close();
        out.close();
    }
    //获得当前是第几个周期
    public String Getcurrent_time()
    {
        long duration = (System.currentTimeMillis() - start_time)/1000;

        int current_freq = (int) Math.ceil(duration/Period)+1;
        //如果当前周期大于已经创建的hash数量，新建hash
        if (read_freq+current_freq>max_freq)
        {
            Jedis jedis = new Jedis("localhost");
            max_freq=current_freq+read_freq;

            Map<String,String> pairs = new HashMap<String,String>();
            pairs.put("period", String.valueOf(Period));
            pairs.put("time", String.valueOf(max_freq));
            pairs.put("set_counter","0");
            pairs.put("get_counter","0");
            pairs.put("delete_counter","0");

            jedis.hmset("record"+max_freq,pairs);
            jedis.close();

        }
        System.out.println("当前时间片："+max_freq);
        return String.valueOf(max_freq);

    }

    /**
     * 读取json文件
     * 将json文件解析到”record+time“命名的Hash中
     *
     * 参数：isFilechange用来判断是初始化的readJson还是修改文件的readJson
     *
     * json文件：json文件的period表示周期统计的周期，单位为秒，time表示第几个周期（时间片），
     * set_counter表示一个周期内set的次数，get_counter表示一个周期内get的次数
     * delete_counter表示一个周期内delete的次数。
     */
    @Test
    public void RedisReadJson(boolean isFilechange) {
        Jedis jedis = new Jedis("127.0.0.1", 6379);
        System.out.println("服务正在运行: " + jedis.ping());
        //如果是修改文件造成的json重新读取则不会刷新开始时间
        if (!isFilechange) {
            start_time = System.currentTimeMillis();
        }
        //String path = JsonTest.class.getClassLoader().getResource("record.json").getPath();
        String s = readJsonFile("C:\\Users\\xuehuijie\\Desktop\\jsondata\\record.json");    //（需要修改路径）
        System.out.println(s);
        JSONObject records = JSON.parseObject(s);
        JSONArray record = records.getJSONArray("record");//构建JSONArray数组

        //将json文件解析到”record+time“命名的Hash中
        for (int i = 0 ; i < record.size();i++){
            JSONObject key = (JSONObject)record.get(i);
            //key.put("period","1");
            String period = (String)key.get("period");
            Period = Long.valueOf(period);
            String time = (String)key.get("time");
            String set_counter=((String)key.get("set_counter"));
            String get_counter=((String)key.get("get_counter"));
            String delete_counter=((String)key.get("delete_counter"));
            read_freq = Integer.parseInt(String.valueOf(key.get("time")));
            //System.out.println("read_freq:"+read_freq);

            Map<String,String> pairs = new HashMap<String,String>();
            pairs.put("period",period);
            pairs.put("time",time);
            pairs.put("set_counter",set_counter);
            pairs.put("get_counter",get_counter);
            pairs.put("delete_counter",delete_counter);

            if (!isFilechange) {
                jedis.hmset("record"+i,pairs);
            }
            else {
                //如果是由修改json导致的读取文件，在原有的周期数（max_freq）的基础上增加
                jedis.hmset("record"+i+max_freq,pairs);
            }
        }
        if (!isFilechange){
            max_freq = read_freq;
        }
        else {
            //如果是由修改json导致的读取文件，在原有的周期数（max_freq）的基础上增加
            max_freq = max_freq + read_freq;
        }
        jedis.close();
    }

    /**
     * 写json文件
     */
    @Test
    public void RedisWriteJson() {
        Jedis jedis = new Jedis("127.0.0.1", 6379);
        System.out.println("服务正在运行: " + jedis.ping());

        //String path = JsonTest.class.getClassLoader().getResource("record.json").getPath();
        JSONObject result = new JSONObject();
        JSONArray recordArray = new JSONArray();

        //将所有周期所对应的命名为“record+time”的hash解析成json对象储存到json文件中
        for (int i = 0;i <=max_freq;i++)
        {
            if (jedis.exists("record"+i))
            {
                Map <String, Object> data = new HashMap<String, Object>();
                data.put("period",jedis.hmget("record"+i,"period").get(0));
                data.put("time",jedis.hmget("record"+i,"time").get(0));
                data.put("set_counter",jedis.hmget("record"+i,"set_counter").get(0));
                data.put("get_counter",jedis.hmget("record"+i,"get_counter").get(0));
                data.put("delete_counter",jedis.hmget("record"+i,"delete_counter").get(0));
                JSONObject record = new JSONObject(data);
                recordArray.set(i,record);
            }
            else
            {
                //如果一个周期之内没进行任何操作，补齐数据
                Map <String, Object> data = new HashMap<String, Object>();
                data.put("period",Period+"");
                data.put("time",i+"");
                data.put("set_counter","0");
                data.put("get_counter","0");
                data.put("delete_counter","0");
                JSONObject record = new JSONObject(data);
                recordArray.set(i,record);
            }

        }

        result.put("record",recordArray);
        try {
            writeFile("C:\\Users\\xuehuijie\\Desktop\\jsondata\\record.json",result.toString());     //（需要修改路径）
        } catch (IOException e) {
            e.printStackTrace();
        }
        jedis.close();
    }

    /**
     * 测试文件监听器
     */
    @Test
    public void testMonitor() {
        //连接本地的 Redis 服务
        Jedis jedis = new Jedis("localhost");

        //监控目录
        String monitorDir = "C:/Users/xuehuijie/Desktop/jsondata";   //（需要修改路径）
        //轮询间隔时间（1000毫秒）
        long interval = TimeUnit.SECONDS.toMillis(1);
        FileAlterationObserver observer = new FileAlterationObserver(monitorDir);

        CustomFileAlterationListener listener = new CustomFileAlterationListener();

        listener.setDemo(this);

        observer.addListener(listener);

        //创建文件变化监听器
        FileAlterationMonitor monitor = new FileAlterationMonitor(interval,observer);
        //开始监听
        try {
            monitor.start();

            //停止监控
            monitor.stop();
        } catch (Exception e) {
            e.printStackTrace();
        }
        jedis.close();

    }

    /**
     * 退出时删除临时记录
     */
    @Test
    public void outDelete() {
        //连接本地的 Redis 服务
        Jedis jedis = new Jedis("localhost");
        for (int i = 0;i <=max_freq;i++)
        {
            jedis.del("record"+i);
        }
        jedis.close();

    }

    /**
     * 使用连接池
     */
    @Test
    public void poolUse() {
        JedisPoolConfig config = new JedisPoolConfig();
        config.setMaxTotal(30);
        config.setMaxIdle(10);

        JedisPool jedisPool = new JedisPool(config, "127.0.0.1", 6379);
        Jedis jedis = jedisPool.getResource();
        jedis.set("date", "5/18");
        String val = jedis.get("name");
        System.out.println(val);
        jedis.close();
        jedisPool.close();
    }

    /**
     * 封装的list的set函数
     */
    @Test
    public void RedisAddList() {
        //连接本地的 Redis 服务
        Jedis jedis = new Jedis("localhost");

        Scanner scanner = new Scanner (System.in);
        System.out.println("请输入key");
        String input_key = scanner.nextLine();
        String input_value = "";

        System.out.println("请输入value,以输入六个零结束输入");
        while (!input_value.equals("000000"))
        {
            input_value = scanner.nextLine();
            //存储数据到列表中
            if (!input_value.equals("000000") && input_value!="")
            {
                jedis.rpush(input_key,input_value);
                //将当前时间所属周期所对应的以“record+time”命名的hash的对应操作的counter incur
                Long new_counter = jedis.hincrBy("record"+Getcurrent_time(),"set_counter",1);
                System.out.println("set:"+new_counter+"");
                jedis.hset("record"+Getcurrent_time(),"set_counter", String.valueOf(new_counter));
            }

        }
        List<String> list = jedis.lrange(input_key, 0, -1);
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
        }
        jedis.close();
    }

    /**
     * 显示所有的keys
     */
    @Test
    public void RedisKey() {
        //连接本地的 Redis 服务
        Jedis jedis = new Jedis("localhost");
        // 获取数据并输出
        Set<String> keys = jedis.keys("*");
        Iterator<String> it=keys.iterator() ;
        while(it.hasNext()){
            String key = it.next();
            System.out.println(key);
        }
        jedis.close();
    }

    /**
     * 封装的string的set函数
     */
    @Test
    public void RedisAddStringKey() {
        //连接本地的 Redis 服务
        Jedis jedis = new Jedis("localhost");

        Scanner scanner = new Scanner (System.in);
        System.out.println("请输入key");
        String input_key = scanner.nextLine();
        System.out.println("请输入value");
        String input_value = scanner.nextLine();

        if (input_key != null && input_value != null)
        {
            jedis.set(input_key,input_value);
            String val=jedis.get(input_key);
            System.out.println("您添加的值是"+val);
        }
        Long new_counter = jedis.hincrBy("record"+Getcurrent_time(),"set_counter",1);
        System.out.println("set:"+new_counter+"");
        jedis.hset("record"+Getcurrent_time(),"set_counter", String.valueOf(new_counter));

        jedis.close();

    }

    /**
     * 封装的删除key函数
     */
    @Test
    public void RedisDeleteKey() {
        //连接本地的 Redis 服务
        Jedis jedis = new Jedis("localhost");

        Scanner scanner = new Scanner (System.in);
        System.out.println("请输入key");
        String input_key = scanner.nextLine();

        if (input_key!=null && jedis.exists(input_key))
        {
            jedis.del(input_key);
            Long new_counter = jedis.hincrBy("record"+Getcurrent_time(),"delete_counter",1);
            System.out.println("delete："+new_counter+"");
            jedis.hset("record"+Getcurrent_time(),"delete_counter", String.valueOf(new_counter));
            System.out.println("您删除的key是"+input_key);
        }
        jedis.close();

    }

    /**
     * 封装的set类型的set函数
     */
    @Test
    public void RedisAddSet() {
        //连接本地的 Redis 服务
        Jedis jedis = new Jedis("localhost");

        Scanner scanner = new Scanner (System.in);
        System.out.println("请输入key");
        String input_key = scanner.nextLine();

        String input_value = "";

        System.out.println("请输入value,以输入六个零结束输入");
        while (!input_value.equals("000000"))
        {
            input_value = scanner.nextLine();
            //存储数据到set中
            if (!input_value.equals("000000") && input_value!="")
            {
                jedis.sadd(input_key,input_value);
                Long new_counter = jedis.hincrBy("record"+Getcurrent_time(),"set_counter",1);
                System.out.println("set:"+new_counter+"");
                jedis.hset("record"+Getcurrent_time(),"set_counter", String.valueOf(new_counter));
            }
        }
        jedis.close();

    }

    /**
     * 封装的sortedSet的set函数
     */
    @Test
    public void RedisAddSortedSet() {
        //连接本地的 Redis 服务
        Jedis jedis = new Jedis("localhost");

        Scanner scanner = new Scanner (System.in);
        System.out.println("请输入key");
        String input_key = scanner.nextLine();

        String input_value = "";
        String input_score = "";

        while (!input_value.equals("000000"))
        {
            System.out.println("请输入value,以输入六个零结束输入");
            input_value = scanner.nextLine();
            System.out.println("请输入score值");
            input_score = scanner.nextLine();
            //存储数据到set中
            if (!input_value.equals("000000") && input_value!="" && input_score!="")
            {
                jedis.zadd(input_key, Double.parseDouble(input_score),input_value);
                Long new_counter = jedis.hincrBy("record"+Getcurrent_time(),"set_counter",1);
                System.out.println("set:"+new_counter+"");
                jedis.hset("record"+Getcurrent_time(),"set_counter", String.valueOf(new_counter));
            }
        }
        jedis.close();

    }

    /**
     * 封装的hash的set函数
     */
    @Test
    public void RedisAddHash() {
        //连接本地的 Redis 服务
        Jedis jedis = new Jedis("localhost");

        Scanner scanner = new Scanner (System.in);
        String input_key = "";
        String input_value = "";
        Map<String,String> pairs = new HashMap<String,String>();

        while (!input_value.equals("000000"))
        {
            System.out.println("请输入entrykey");
            input_key=scanner.nextLine();
            System.out.println("请输入entryvalue,以输入六个零结束输入");
            input_value = scanner.nextLine();
            //存储数据到Hash中
            if (!input_value.equals("000000") && input_value!="")
            {
                pairs.put(input_key,input_value);
                Long new_counter = jedis.hincrBy("record"+Getcurrent_time(),"set_counter",1);
                System.out.println("set:"+new_counter+"");
                jedis.hset("record"+Getcurrent_time(),"set_counter", String.valueOf(new_counter));
            }
        }
        String input_hash_key="";
        System.out.println("请输入Hashkey");
        input_hash_key = scanner.nextLine();
        if (input_hash_key!="")
        {
            jedis.hmset(input_hash_key,pairs);
        }

        jedis.close();
    }

    /**
     * 封装的输入key的get函数
     */
    @Test
    public void RedisGet() {
        //连接本地的 Redis 服务
        Jedis jedis = new Jedis("localhost");

        Scanner scanner = new Scanner (System.in);
        System.out.println("请输入key");
        String input_key = scanner.nextLine();

        if (jedis.exists(input_key))
        {
            String type=jedis.type(input_key);
            System.out.println(type);

            switch (type)
            {
                case "list":
                {
                    List<String> list = jedis.lrange(input_key, 0, -1);
                    for (int i = 0; i < list.size(); i++) {
                        System.out.println(list.get(i));
                    }
                    Long new_counter = jedis.hincrBy("record"+Getcurrent_time(),"get_counter",1);
                    System.out.println("get:"+new_counter+"");
                    jedis.hset("record"+Getcurrent_time(),"get_counter", String.valueOf(new_counter));
                    break;
                }
                case "string":
                {
                    System.out.println(jedis.get(input_key));
                    Long new_counter = jedis.hincrBy("record"+Getcurrent_time(),"get_counter",1);
                    System.out.println("get:"+new_counter+"");
                    jedis.hset("record"+Getcurrent_time(),"get_counter", String.valueOf(new_counter));
                    break;
                }
                case "set":
                {
                    System.out.println(jedis.smembers(input_key));
                    Long new_counter = jedis.hincrBy("record"+Getcurrent_time(),"get_counter",1);
                    System.out.println("get:"+new_counter+"");
                    jedis.hset("record"+Getcurrent_time(),"get_counter", String.valueOf(new_counter));
                    break;
                }
                case "zset":
                {
                    System.out.println(jedis.zrevrange(input_key,0,-1));
                    Long new_counter = jedis.hincrBy("record"+Getcurrent_time(),"get_counter",1);
                    System.out.println("get:"+new_counter+"");
                    jedis.hset("record"+Getcurrent_time(),"get_counter", String.valueOf(new_counter));
                    break;
                }
                case "hash":
                {
                    Iterator<String> iterator = jedis.hkeys(input_key).iterator();
                    while(iterator.hasNext())
                    {
                        String key = iterator.next();
                        System.out.println(key+":"+jedis.hmget(input_key,key));
                    }
                    if (!input_key.contains("record"))
                    {
                        Long new_counter = jedis.hincrBy("record"+Getcurrent_time(),"get_counter",1);
                        System.out.println("get:"+new_counter+"");
                        jedis.hset("record"+Getcurrent_time(),"get_counter", String.valueOf(new_counter));
                    }
                    break;
                }
                default:
                {
                    System.out.println("opening soon");
                }
            }
        }
        jedis.close();
    }

    /**
     * 封装的修改给定key值的value
     */
    @Test
    public void RedisModify() {
        //连接本地的 Redis 服务
        Jedis jedis = new Jedis("localhost");

        Scanner scanner = new Scanner (System.in);
        System.out.println("请输入key");
        String input_key = scanner.nextLine();

        if (jedis.exists(input_key))
        {
            String type=jedis.type(input_key);
            System.out.println(type);

            switch (type)
            {
                case "string":
                {
                    System.out.println("请输入选项（1：添加 2：修改 3：删除）");
                    String operate=scanner.nextLine();

                    if (operate.equals("1"))
                    {
                        System.out.println("请输入添加的value");
                        String input_value=scanner.nextLine();
                        jedis.append(input_key,input_value);
                        Long new_counter = jedis.hincrBy("record"+Getcurrent_time(),"set_counter",1);
                        System.out.println("set"+new_counter+"");
                        jedis.hset("record"+Getcurrent_time(),"set_counter", String.valueOf(new_counter));
                        System.out.println(jedis.get(input_key));
                    } else if (operate.equals("2"))
                    {
                        System.out.println("请输入修改的value");
                        String input_value=scanner.nextLine();
                        jedis.set(input_key,input_value);
                        Long new_counter = jedis.hincrBy("record"+Getcurrent_time(),"set_counter",1);
                        System.out.println("set"+new_counter+"");
                        jedis.hset("record"+Getcurrent_time(),"set_counter", String.valueOf(new_counter));
                        System.out.println(jedis.get(input_key));

                    } else if (operate.equals("3"))
                    {
                        Long new_counter = jedis.hincrBy("record"+Getcurrent_time(),"delete_counter",1);
                        System.out.println("delete:"+new_counter+"");
                        jedis.hset("record"+Getcurrent_time(),"delete_counter", String.valueOf(new_counter));
                        jedis.del(input_key);
                    } else
                    {
                        System.out.println("input error");
                    }
                    break;
                }
                case "list":
                {
                    System.out.println("请输入选项（1：添加 2：修改 3：删除）");
                    String operate=scanner.nextLine();

                    if (operate.equals("1"))
                    {
                        System.out.println("请输入添加的value");
                        String input_value=scanner.nextLine();
                        jedis.rpush(input_key,input_value);
                        Long new_counter = jedis.hincrBy("record"+Getcurrent_time(),"set_counter",1);
                        System.out.println("set:"+new_counter+"");
                        jedis.hset("record"+Getcurrent_time(),"set_counter", String.valueOf(new_counter));
                        System.out.println("成功添加"+input_value);
                    } else if (operate.equals("2"))
                    {
                        System.out.println("请输入修改的value和位置");
                        String input_value=scanner.nextLine();
                        String input_position=scanner.nextLine();
                        jedis.lset(input_key, Long.parseLong(input_position),input_value);
                        Long new_counter = jedis.hincrBy("record"+Getcurrent_time(),"set_counter",1);
                        System.out.println("set:"+new_counter+"");
                        jedis.hset("record"+Getcurrent_time(),"set_counter", String.valueOf(new_counter));
                        System.out.println("成功修改"+input_value);

                    } else if (operate.equals("3"))
                    {
                        System.out.println("请输入删除的value和位置");
                        String input_position=scanner.nextLine();
                        String input_value=jedis.lindex(input_key,Integer.parseInt(input_position));
                        jedis.lrem(input_key, Long.parseLong(input_position),input_value);
                        Long new_counter = jedis.hincrBy("record"+Getcurrent_time(),"delete_counter",1);
                        System.out.println("delete:"+new_counter+"");
                        jedis.hset("record"+Getcurrent_time(),"delete_counter", String.valueOf(new_counter));
                        System.out.println("成功删除"+input_value);
                    } else
                    {
                        System.out.println("input error");
                    }
                    break;
                }
                case "set":
                {
                    System.out.println("请输入选项（1：添加 2：删除）");
                    String operate=scanner.nextLine();

                    if (operate.equals("1"))
                    {
                        System.out.println("请输入添加的value");
                        String input_value=scanner.nextLine();
                        jedis.sadd(input_key,input_value);
                        Long new_counter = jedis.hincrBy("record"+Getcurrent_time(),"set_counter",1);
                        System.out.println("set:"+new_counter+"");
                        jedis.hset("record"+Getcurrent_time(),"set_counter", String.valueOf(new_counter));
                        System.out.println("成功添加"+input_value);
                    } else if (operate.equals("2"))
                    {
                        System.out.println("请输入删除的value");
                        String input_value=scanner.nextLine();
                        jedis.srem(input_key,input_value);
                        Long new_counter = jedis.hincrBy("record"+Getcurrent_time(),"delete_counter",1);
                        System.out.println("delete:"+new_counter+"");
                        jedis.hset("record"+Getcurrent_time(),"delete_counter", String.valueOf(new_counter));
                        System.out.println("成功删除"+input_value);
                    } else
                    {
                        System.out.println("input error");
                    }
                    break;
                }
                case "zset":
                {
                    System.out.println("请输入选项（1：添加 2：删除）");
                    String operate=scanner.nextLine();

                    if (operate.equals("1"))
                    {
                        System.out.println("请输入添加的value和score");
                        String input_value=scanner.nextLine();
                        String input_score=scanner.nextLine();
                        jedis.zadd(input_key, Double.parseDouble(input_score),input_value);
                        Long new_counter = jedis.hincrBy("record"+Getcurrent_time(),"set_counter",1);
                        System.out.println("set:"+new_counter+"");
                        jedis.hset("record"+Getcurrent_time(),"set_counter", String.valueOf(new_counter));
                        System.out.println("成功添加"+input_value);
                    } else  if (operate.equals("2"))
                    {
                        System.out.println("请输入删除的value");
                        String input_value=scanner.nextLine();
                        jedis.zrem(input_key,input_value);
                        Long new_counter = jedis.hincrBy("record"+Getcurrent_time(),"delete_counter",1);
                        System.out.println("delete:"+new_counter+"");
                        jedis.hset("record"+Getcurrent_time(),"delete_counter", String.valueOf(new_counter));
                        System.out.println("成功删除"+input_value);
                    } else
                    {
                        System.out.println("input error");
                    }
                    break;
                }
                case "hash":
                {
                    System.out.println("请输入选项（1：添加 2：修改 3：删除）");
                    String operate=scanner.nextLine();

                    if (operate.equals("1"))
                    {
                        System.out.println("请输入添加的entry和value");
                        String input_entry=scanner.nextLine();
                        String input_value=scanner.nextLine();
                        jedis.hset(input_key,input_entry,input_value);

                        Long new_counter = jedis.hincrBy("record"+Getcurrent_time(),"set_counter",1);
                        System.out.println("set:"+new_counter+"");
                        jedis.hset("record"+Getcurrent_time(),"set_counter", String.valueOf(new_counter));

                        System.out.println("成功添加"+input_value);
                    } else if (operate.equals("2"))
                    {
                        System.out.println("请输入修改的entry和value");
                        String input_entry=scanner.nextLine();
                        String input_value=scanner.nextLine();
                        if (jedis.hexists(input_key,input_entry))
                        {
                            jedis.hset(input_key, input_entry,input_value);

                            Long new_counter = jedis.hincrBy("record"+Getcurrent_time(),"set_counter",1);
                            System.out.println("set:"+new_counter+"");
                            jedis.hset("record"+Getcurrent_time(),"set_counter", String.valueOf(new_counter));

                            System.out.println("成功修改"+input_entry);
                        }
                        else
                        {
                            System.out.println("entry不存在");
                        }

                    } else if (operate.equals("3"))
                    {
                        System.out.println("请输入删除的entry");
                        String input_entry=scanner.nextLine();
                        jedis.hdel(input_key, input_entry);
                        Long new_counter = jedis.hincrBy("record"+Getcurrent_time(),"delete_counter",1);
                        System.out.println("delete:"+new_counter+"");
                        jedis.hset("record"+Getcurrent_time(),"delete_counter", String.valueOf(new_counter));
                        System.out.println("成功删除"+input_entry);
                    } else
                    {
                        System.out.println("input error");
                    }
                    break;
                }
                default:
                {
                    System.out.println("opening soon");
                }
            }
        }
        jedis.close();
    }

}
