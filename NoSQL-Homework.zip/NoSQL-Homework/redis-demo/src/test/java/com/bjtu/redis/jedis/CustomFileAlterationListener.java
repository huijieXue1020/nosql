package com.bjtu.redis.jedis;

import org.apache.commons.io.monitor.FileAlterationListenerAdaptor;
import org.apache.commons.io.monitor.FileAlterationObserver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.text.MessageFormat;

/**
 * 自定义文件变化监听器
 * 当检测到json文件的修改，会重新读取json文件内的信息，之前操作的counter保留，
 * 根据新读取的json文件内的信息，周期个数在原有的周期个数基础上增加，退出时全部写在json文件当中
 */
public class CustomFileAlterationListener extends FileAlterationListenerAdaptor {
    private Logger logger = LoggerFactory.getLogger(getClass());
    private JedisDemo demo; //当做参数穿过来的demo对象

    public void setDemo(JedisDemo demo) {
        this.demo = demo;
    }

    @Override
    public void onStart(FileAlterationObserver observer) {
        super.onStart(observer);
    }

    @Override
    public void onStop(FileAlterationObserver observer) {
        super.onStop(observer);
    }

    @Override
    public void onDirectoryCreate(File directory) {
        logger.info(MessageFormat.format("目录[{0}]被创建",directory.getAbsolutePath()));
    }

    @Override
    public void onDirectoryChange(File directory) {
        logger.info(MessageFormat.format("目录[{0}]被修改",directory.getAbsolutePath()));
    }

    @Override
    public void onDirectoryDelete(File directory) {
        logger.info(MessageFormat.format("目录[{0}]被删除",directory.getAbsolutePath()));
    }

    @Override
    public void onFileCreate(File file) {
        logger.info(MessageFormat.format("文件[{0}]被创建",file.getAbsolutePath()));
    }

    @Override
    public void onFileChange(File file) {
        logger.info(MessageFormat.format("文件[{0}]被修改",file.getAbsolutePath()));
        //检测到文件修改之后重新读取json文件
        demo.RedisReadJson(true);
    }

    @Override
    public void onFileDelete(File file) {
        logger.info(MessageFormat.format("文件[{0}]被删除",file.getAbsolutePath()));
    }
}
