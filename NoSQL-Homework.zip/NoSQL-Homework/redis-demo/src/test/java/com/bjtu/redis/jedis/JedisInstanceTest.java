package com.bjtu.redis.jedis;

import org.apache.commons.io.monitor.FileAlterationMonitor;
import org.apache.commons.io.monitor.FileAlterationObserver;
import org.junit.Test;

import com.bjtu.redis.JedisInstance;

import redis.clients.jedis.Jedis;

import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class JedisInstanceTest {

    /**
     * 基本使用
     * 控制台根据提示输入数字选项完成set、get等操作
     */
    @Test
    public void test() {
        Jedis jedis = JedisInstance.getInstance().getResource();
        JedisDemo demo=new JedisDemo();
        demo.RedisReadJson(false);
        //监控目录（需要修改路径）
        String monitorDir = "C:/Users/xuehuijie/Desktop/jsondata";
        //轮询间隔时间（1000毫秒）
        long interval = TimeUnit.SECONDS.toMillis(1);

        FileAlterationObserver observer = new FileAlterationObserver(monitorDir);
        //自定义的文件监听器
        CustomFileAlterationListener listener = new CustomFileAlterationListener();
        listener.setDemo(demo);
        observer.addListener(listener);
        //创建文件变化监听器
        FileAlterationMonitor monitor = new FileAlterationMonitor(interval,observer);
        //开始监听
        try {
            monitor.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
        boolean isout=true;
        while(isout)
        {
            System.out.println("请输入选项（1：set 2：get 3：显示所有key 4：退出");
            System.out.println("5：删除key 6：修改value）");
            String input="";
            Scanner scanner = new Scanner (System.in);
            input = scanner.next();

            switch (input)
            {
                case "1":
                    demo.RedisSet();
                    break;
                case "2":
                    demo.RedisGet();
                    break;
                case "3":
                    demo.RedisKey();
                    break;
                case "4":
                    isout = false;
                    demo.RedisWriteJson();
                    demo.outDelete();
                    System.out.println("您已退出");
                    break;
                case "5":
                    demo.RedisDeleteKey();
                    break;
                case "6":
                    demo.RedisModify();
                    break;
                default:
                    System.out.println("input error");
            }
        }
        //停止监控
        try {
            monitor.stop();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
